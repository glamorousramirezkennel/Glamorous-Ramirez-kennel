
<?php
function grk_setup(){ add_theme_support('title-tag'); add_theme_support('post-thumbnails'); register_nav_menus(array('primary'=>'Primary Menu')); }
add_action('after_setup_theme','grk_setup');
function grk_scripts(){ wp_enqueue_style('grk-style', get_stylesheet_uri(), array(), '1.0'); }
add_action('wp_enqueue_scripts','grk_scripts');
?>
