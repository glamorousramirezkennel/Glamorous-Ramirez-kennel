
<?php get_header(); ?><section class="section"><h1>Glamorous Ramirez Kennel</h1>
<p>Where Elegance Meets Loyalty.</p>
</section><?php get_footer(); ?>
