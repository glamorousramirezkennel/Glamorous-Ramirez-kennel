
<?php ?><!doctype html><html <?php language_attributes(); ?>><head>
<meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="<?php echo esc_url(get_template_directory_uri().'/assets/favicon.ico'); ?>" sizes="any">
<?php wp_head(); ?></head><body <?php body_class(); ?>>
<header class="site-header"><div class="container brand">
<img class="logo" src="<?php echo esc_url(get_template_directory_uri().'/assets/logo-transparent.png'); ?>" alt="Glamorous Ramirez Kennel">
<div class="tagline">Where Elegance Meets Loyalty</div>
<nav class="navbar"><?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'fallback_cb'=>false)); ?></nav>
</div></header><main class="container">
