
<?php $year = date('Y'); ?></main><footer class="site-footer"><div class="container">
<div>© <?php echo $year; ?> Glamorous Ramirez Kennel — Based in Missouri • All rights reserved.</div>
</div><?php wp_footer(); ?></footer></body></html>
